# Reproducing Manuscript Tables

1. Install the dependencies with Python 3.13.
2. Generate split files:

```powershell
.\.venv\Scripts\python scripts\make_dataset_splits.py --data-root "E:\FOLDER_E\Freelancing_work\Pratibha_YCCE\Work 2\COD Dataset"
```

3. Train each backbone independently:

```powershell
.\.venv\Scripts\python scripts\train.py --config configs\deepcamnet_r101.yaml --output-dir runs
.\.venv\Scripts\python scripts\train.py --config configs\deepcamnet_mv3.yaml --output-dir runs
```

4. Copy the best checkpoints to `weights/` if preparing a public release:

```powershell
Copy-Item runs\deepcamnet_r101\best.pth weights\deepcamnet_r101.pth
Copy-Item runs\deepcamnet_mv3\best.pth weights\deepcamnet_mv3.pth
```

5. Run the dataset-specific commands in `evaluation_commands.md`.

The scripts report mDice, mIoU, MAE, pixel accuracy, precision, recall, F1, S-measure, E-measure, and Fmax. The fixed validation-selected threshold is 0.35 by default, as described in the revised manuscript.
