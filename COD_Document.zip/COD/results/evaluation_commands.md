# Evaluation Commands

Run these commands from the `DeepCamNet-COD` folder after installing `requirements.txt` and training or placing checkpoints in `weights/`.

## ResNet101

```powershell
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint weights\deepcamnet_r101.pth --dataset CAMO
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint weights\deepcamnet_r101.pth --dataset CHAMELEON
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint weights\deepcamnet_r101.pth --dataset COD10K
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint weights\deepcamnet_r101.pth --dataset NC4K
```

## MobileNetV3

```powershell
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_mv3.yaml --checkpoint weights\deepcamnet_mv3.pth --dataset CAMO
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_mv3.yaml --checkpoint weights\deepcamnet_mv3.pth --dataset CHAMELEON
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_mv3.yaml --checkpoint weights\deepcamnet_mv3.pth --dataset COD10K
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_mv3.yaml --checkpoint weights\deepcamnet_mv3.pth --dataset NC4K
```
