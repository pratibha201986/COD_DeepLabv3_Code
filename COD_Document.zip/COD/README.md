# DeepCamNet-COD

This folder converts the previous Colab-style DeepCamNet experiments into a local Python 3.13 reproducibility package. It is prepared to address the reviewer request for runnable scripts, dependency versions, dataset partitions, evaluation commands, pretrained-weight placeholders, license information, and instructions for reproducing the reported COD results.

## Environment

Use Python 3.13 on Windows:

```powershell
cd "E:\FOLDER_E\Freelancing_work\Pratibha_YCCE\Work 2\PYTHON WORK 2 CODE\DeepCamNet-COD"
py -3.13 -m venv .venv
.\.venv\Scripts\python -m pip install --upgrade pip
.\.venv\Scripts\python -m pip install -r requirements.txt
```

The pinned dependency file uses versions available for Python 3.13:

- torch 2.12.1
- torchvision 0.27.1
- numpy 2.3.3
- pillow 11.3.0
- PyYAML 6.0.3
- tqdm 4.68.3

## Dataset Layout

The default local dataset root is:

```text
'/content/drive/COD Dataset'
```

Expected structure:

```text
COD Dataset/
+-- train-dataset-cod/TrainDataset/
|   +-- Imgs/
|   +-- GT/
+-- test-dataset-cod/TestDataset/
    +-- CAMO/Imgs, CAMO/GT
    +-- CHAMELEON/Imgs, CHAMELEON/GT
    +-- COD10K/Imgs, COD10K/GT
    +-- NC4K/Imgs, NC4K/GT
```

Generate split files:

```powershell
.\.venv\Scripts\python scripts\make_dataset_splits.py --data-root '/content/drive/COD Dataset'
```

CAD and MoCA split placeholder files are included because those frame datasets are not present in the local `COD Dataset` folder. Add tab-separated image/mask paths when CAD or MoCA frames are added.

## Training

Train the ResNet101 configuration:

```powershell
.\.venv\Scripts\python scripts\train.py --config configs\deepcamnet_r101.yaml --output-dir runs
```

Train the MobileNetV3 configuration:

```powershell
.\.venv\Scripts\python scripts\train.py --config configs\deepcamnet_mv3.yaml --output-dir runs
```

For a fast smoke test:

```powershell
.\.venv\Scripts\python scripts\train.py --config configs\deepcamnet_mv3.yaml --output-dir runs_smoke --debug-limit 8
```

## Evaluation

Evaluate a trained checkpoint:

```powershell
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint runs\deepcamnet_r101\best.pth --dataset CAMO
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint runs\deepcamnet_r101\best.pth --dataset CHAMELEON
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint runs\deepcamnet_r101\best.pth --dataset COD10K
.\.venv\Scripts\python scripts\evaluate.py --config configs\deepcamnet_r101.yaml --checkpoint runs\deepcamnet_r101\best.pth --dataset NC4K
```

The default validation-guided inference threshold is `0.35`, matching the revised manuscript table. Override it with `--threshold` only for ablation.

## Inference

```powershell
.\.venv\Scripts\python scripts\infer.py --config configs\deepcamnet_r101.yaml --checkpoint runs\deepcamnet_r101\best.pth --input "E:\FOLDER_E\Freelancing_work\Pratibha_YCCE\Work 2\COD Dataset\test-dataset-cod\TestDataset\CAMO\Imgs" --output-dir results\predictions\CAMO_R101
```

## Notes For Public Release

- Upload trained weights before claiming that pretrained weights are available.
- Keep dataset licenses with the original dataset providers.
- Replace any placeholder repository URL in the manuscript with the final clickable GitHub, Zenodo, or institutional repository URL.
