from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from deepcamnet.config import load_config
from deepcamnet.dataset import CODSegmentationDataset, PairedCODTransform, read_split_file
from deepcamnet.losses import HybridCODLoss
from deepcamnet.metrics import MetricAccumulator
from deepcamnet.models import build_deepcamnet, load_checkpoint
from deepcamnet.utils import choose_device, save_json, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a DeepCamNet configuration.")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "runs")
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--debug-limit", type=int, default=None)
    return parser.parse_args()


def make_transform(config: dict, train: bool) -> PairedCODTransform:
    train_cfg = config.get("train", {})
    return PairedCODTransform(
        image_size=int(config.get("image_size", 256)),
        train=train,
        random_resized_crop=bool(train_cfg.get("random_resized_crop", False)) if train else False,
        horizontal_flip_p=float(train_cfg.get("horizontal_flip_p", 0.5)),
        rotation_degrees=float(train_cfg.get("rotation_degrees", 0.0)),
        color_jitter=tuple(train_cfg.get("color_jitter", [0.0, 0.0, 0.0, 0.0])) if train else None,
    )


def evaluate(model: torch.nn.Module, loader: DataLoader, device: torch.device, threshold: float) -> dict[str, float]:
    model.eval()
    metrics = MetricAccumulator()
    with torch.no_grad():
        for images, masks, _ in tqdm(loader, desc="Validation", leave=False):
            images = images.to(device, non_blocking=True)
            masks = masks.to(device, non_blocking=True)
            logits = model(images)["out"]
            logits = F.interpolate(logits, size=masks.shape[-2:], mode="bilinear", align_corners=False)
            prob = torch.sigmoid(logits)
            metrics.update(prob, masks, threshold=threshold)
    return metrics.compute()


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    seed_everything(int(config.get("seed", 42)))
    device = choose_device(args.device)

    data_root = Path(config["data"]["root"])
    train_pairs = read_split_file(ROOT / config["data"]["train_split"], data_root)
    val_pairs = read_split_file(ROOT / config["data"]["val_split"], data_root)

    train_dataset = CODSegmentationDataset(train_pairs, make_transform(config, train=True), limit=args.debug_limit)
    val_dataset = CODSegmentationDataset(val_pairs, make_transform(config, train=False), limit=args.debug_limit)
    train_cfg = config.get("train", {})

    train_loader = DataLoader(
        train_dataset,
        batch_size=int(train_cfg.get("batch_size", 4)),
        shuffle=True,
        num_workers=int(train_cfg.get("num_workers", 0)),
        pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=int(train_cfg.get("batch_size", 4)),
        shuffle=False,
        num_workers=int(train_cfg.get("num_workers", 0)),
        pin_memory=device.type == "cuda",
    )

    model = build_deepcamnet(config["backbone"], pretrained=bool(config.get("pretrained_backbone", True))).to(device)
    if args.resume:
        load_checkpoint(model, str(args.resume), device)

    loss_cfg = config.get("loss", {})
    criterion = HybridCODLoss(**loss_cfg).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(train_cfg.get("learning_rate", 1e-4)),
        weight_decay=float(train_cfg.get("weight_decay", 1e-4)),
    )
    scheduler = torch.optim.lr_scheduler.StepLR(
        optimizer,
        step_size=int(train_cfg.get("scheduler_step_size", 25)),
        gamma=float(train_cfg.get("scheduler_gamma", 0.5)),
    )
    scaler = torch.cuda.amp.GradScaler(enabled=bool(train_cfg.get("amp", True)) and device.type == "cuda")

    run_dir = args.output_dir / str(config.get("experiment_name", config["backbone"]))
    run_dir.mkdir(parents=True, exist_ok=True)
    metrics_path = run_dir / "metrics_history.csv"
    threshold = float(config.get("threshold", 0.35))
    best_dice = -1.0

    with metrics_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["epoch", "train_loss", "mDice", "mIoU", "MAE", "Accuracy", "Precision", "Recall", "Sm", "Em", "Fmax"],
        )
        writer.writeheader()

        for epoch in range(1, int(train_cfg.get("epochs", 100)) + 1):
            model.train()
            total_loss = 0.0
            for images, masks, _ in tqdm(train_loader, desc=f"Epoch {epoch}"):
                images = images.to(device, non_blocking=True)
                masks = masks.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with torch.cuda.amp.autocast(enabled=scaler.is_enabled()):
                    logits = model(images)["out"]
                    logits = F.interpolate(logits, size=masks.shape[-2:], mode="bilinear", align_corners=False)
                    loss = criterion(logits, masks)
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                total_loss += float(loss.item())

            scheduler.step()
            train_loss = total_loss / max(len(train_loader), 1)
            val_metrics = evaluate(model, val_loader, device, threshold=threshold)
            row = {"epoch": epoch, "train_loss": train_loss, **val_metrics}
            writer.writerow(row)
            handle.flush()

            checkpoint = {
                "model": model.state_dict(),
                "config": config,
                "epoch": epoch,
                "metrics": val_metrics,
                "threshold": threshold,
            }
            torch.save(checkpoint, run_dir / "last.pth")
            if val_metrics["mDice"] > best_dice:
                best_dice = val_metrics["mDice"]
                torch.save(checkpoint, run_dir / "best.pth")
                save_json(run_dir / "best_metrics.json", {"epoch": epoch, **val_metrics})

            print(
                f"Epoch {epoch}: loss={train_loss:.4f}, "
                f"mDice={val_metrics['mDice']:.4f}, mIoU={val_metrics['mIoU']:.4f}, MAE={val_metrics['MAE']:.4f}"
            )


if __name__ == "__main__":
    main()
