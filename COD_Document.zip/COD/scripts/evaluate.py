from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from deepcamnet.config import load_config
from deepcamnet.dataset import CODSegmentationDataset, PairedCODTransform, read_split_file
from deepcamnet.metrics import MetricAccumulator
from deepcamnet.models import build_deepcamnet, load_checkpoint
from deepcamnet.utils import choose_device, save_json, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate DeepCamNet on COD benchmarks.")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", choices=["CAMO", "CHAMELEON", "COD10K", "NC4K"], required=True)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--threshold", type=float, default=None)
    parser.add_argument("--debug-limit", type=int, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    seed_everything(int(config.get("seed", 42)))
    device = choose_device(args.device)
    data_root = Path(config["data"]["root"])
    split_rel = config["data"]["test_splits"][args.dataset]
    pairs = read_split_file(ROOT / split_rel, data_root)
    dataset = CODSegmentationDataset(
        pairs,
        PairedCODTransform(image_size=int(config.get("image_size", 256)), train=False),
        limit=args.debug_limit,
    )
    loader = DataLoader(
        dataset,
        batch_size=int(config.get("train", {}).get("batch_size", 4)),
        shuffle=False,
        num_workers=int(config.get("train", {}).get("num_workers", 0)),
        pin_memory=device.type == "cuda",
    )

    model = build_deepcamnet(config["backbone"], pretrained=False).to(device)
    checkpoint = load_checkpoint(model, str(args.checkpoint), device)
    threshold = args.threshold if args.threshold is not None else float(checkpoint.get("threshold", config.get("threshold", 0.35)))

    model.eval()
    metrics = MetricAccumulator()
    with torch.no_grad():
        for images, masks, _ in tqdm(loader, desc=f"Evaluating {args.dataset}"):
            images = images.to(device, non_blocking=True)
            masks = masks.to(device, non_blocking=True)
            logits = model(images)["out"]
            logits = F.interpolate(logits, size=masks.shape[-2:], mode="bilinear", align_corners=False)
            metrics.update(torch.sigmoid(logits), masks, threshold=threshold)

    result = {
        "dataset": args.dataset,
        "checkpoint": str(args.checkpoint),
        "threshold": threshold,
        **metrics.compute(),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / f"{config['backbone']}_{args.dataset}_metrics.json"
    csv_path = args.output_dir / f"{config['backbone']}_{args.dataset}_metrics.csv"
    save_json(json_path, result)
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result.keys()))
        writer.writeheader()
        writer.writerow(result)
    print(result)


if __name__ == "__main__":
    main()
