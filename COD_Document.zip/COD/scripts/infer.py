from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch
from PIL import Image
from torch.nn import functional as F
from torchvision.transforms import functional as TF
from tqdm import tqdm

from deepcamnet.config import load_config
from deepcamnet.dataset import IMAGE_EXTENSIONS, PairedCODTransform
from deepcamnet.models import build_deepcamnet, load_checkpoint
from deepcamnet.utils import choose_device


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run DeepCamNet inference on images.")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True, help="Image file or image directory.")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results" / "predictions")
    parser.add_argument("--threshold", type=float, default=None)
    parser.add_argument("--device", default="auto")
    return parser.parse_args()


def list_images(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    return sorted(p for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    device = choose_device(args.device)
    transform = PairedCODTransform(image_size=int(config.get("image_size", 256)), train=False)
    model = build_deepcamnet(config["backbone"], pretrained=False).to(device)
    checkpoint = load_checkpoint(model, str(args.checkpoint), device)
    threshold = args.threshold if args.threshold is not None else float(checkpoint.get("threshold", config.get("threshold", 0.35)))
    model.eval()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    for image_path in tqdm(list_images(args.input), desc="Inference"):
        image = Image.open(image_path).convert("RGB")
        dummy_mask = Image.new("L", image.size, 0)
        image_tensor, _ = transform(image, dummy_mask)
        with torch.no_grad():
            logits = model(image_tensor.unsqueeze(0).to(device))["out"]
            logits = F.interpolate(logits, size=(image.height, image.width), mode="bilinear", align_corners=False)
            prob = torch.sigmoid(logits).squeeze().cpu()
            mask = (prob > threshold).to(torch.uint8) * 255
        TF.to_pil_image(mask).save(args.output_dir / f"{image_path.stem}_mask.png")


if __name__ == "__main__":
    main()
