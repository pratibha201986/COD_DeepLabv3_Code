from __future__ import annotations

import argparse
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATASET_ROOT = Path(r"E:\FOLDER_E\Freelancing_work\Pratibha_YCCE\Work 2\COD Dataset")

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
MASK_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def find_image_mask_pairs(image_dir: Path, mask_dir: Path) -> list[tuple[Path, Path]]:
    mask_by_stem = {
        path.stem: path
        for path in sorted(mask_dir.iterdir())
        if path.is_file() and path.suffix.lower() in MASK_EXTENSIONS
    }
    pairs: list[tuple[Path, Path]] = []
    for image_path in sorted(image_dir.iterdir()):
        if image_path.is_file() and image_path.suffix.lower() in IMAGE_EXTENSIONS:
            mask_path = mask_by_stem.get(image_path.stem)
            if mask_path is not None:
                pairs.append((image_path, mask_path))
    return pairs


def write_split_file(split_file: Path, pairs: list[tuple[Path, Path]], data_root: Path) -> None:
    split_file.parent.mkdir(parents=True, exist_ok=True)
    with split_file.open("w", encoding="utf-8", newline="\n") as handle:
        for image_path, mask_path in pairs:
            image_rel = image_path.resolve().relative_to(data_root.resolve())
            mask_rel = mask_path.resolve().relative_to(data_root.resolve())
            handle.write(f"{image_rel.as_posix()}\t{mask_rel.as_posix()}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create DeepCamNet dataset split files.")
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATASET_ROOT)
    parser.add_argument("--out-dir", type=Path, default=ROOT / "dataset_splits")
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    train_dir = args.data_root / "train-dataset-cod" / "TrainDataset"
    train_pairs = find_image_mask_pairs(train_dir / "Imgs", train_dir / "GT")
    rng = random.Random(args.seed)
    shuffled = train_pairs[:]
    rng.shuffle(shuffled)
    val_count = int(round(len(shuffled) * args.val_ratio))
    val_pairs = shuffled[:val_count]
    train_pairs_split = shuffled[val_count:]

    write_split_file(args.out_dir / "TrainDataset_all.txt", train_pairs, args.data_root)
    write_split_file(args.out_dir / "TrainDataset_train.txt", train_pairs_split, args.data_root)
    write_split_file(args.out_dir / "TrainDataset_val.txt", val_pairs, args.data_root)

    # Alias names make the release easier to understand when a reviewer expects COD train files.
    write_split_file(args.out_dir / "COD_train.txt", train_pairs_split, args.data_root)
    write_split_file(args.out_dir / "COD_val.txt", val_pairs, args.data_root)

    test_root = args.data_root / "test-dataset-cod" / "TestDataset"
    for name in ["CAMO", "CHAMELEON", "COD10K", "NC4K"]:
        dataset_dir = test_root / name
        pairs = find_image_mask_pairs(dataset_dir / "Imgs", dataset_dir / "GT")
        write_split_file(args.out_dir / f"{name}_test.txt", pairs, args.data_root)
        print(f"{name}: {len(pairs)} pairs")

    for video_name in ["CAD", "MoCA"]:
        path = args.out_dir / f"{video_name}_test.txt"
        if not path.exists():
            path.write_text(
                "# Add image_path<TAB>mask_path entries here when the "
                f"{video_name} frame dataset is available locally.\n",
                encoding="utf-8",
            )

    print(f"Train pairs: {len(train_pairs_split)}")
    print(f"Validation pairs: {len(val_pairs)}")
    print(f"Split files written to: {args.out_dir}")


if __name__ == "__main__":
    main()
