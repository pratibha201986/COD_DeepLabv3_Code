from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class DiceLoss(nn.Module):
    def __init__(self, smooth: float = 1e-6) -> None:
        super().__init__()
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        prob = torch.sigmoid(logits)
        prob = prob.flatten(start_dim=1)
        target = target.flatten(start_dim=1)
        intersection = (prob * target).sum(dim=1)
        denominator = prob.sum(dim=1) + target.sum(dim=1)
        loss = 1.0 - (2.0 * intersection + self.smooth) / (denominator + self.smooth)
        return loss.mean()


class FocalLossWithLogits(nn.Module):
    def __init__(self, gamma: float = 2.0, alpha: float = 0.25, reduction: str = "mean") -> None:
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        bce = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
        prob = torch.sigmoid(logits)
        p_t = prob * target + (1.0 - prob) * (1.0 - target)
        alpha_t = self.alpha * target + (1.0 - self.alpha) * (1.0 - target)
        loss = alpha_t * (1.0 - p_t).pow(self.gamma) * bce
        if self.reduction == "sum":
            return loss.sum()
        if self.reduction == "none":
            return loss
        return loss.mean()


class HybridCODLoss(nn.Module):
    """Dice + BCE + Focal loss used for DeepCamNet training."""

    def __init__(
        self,
        dice_weight: float = 1.0,
        bce_weight: float = 1.0,
        focal_weight: float = 1.0,
        focal_gamma: float = 2.0,
        focal_alpha: float = 0.25,
        positive_weight: float = 5.0,
    ) -> None:
        super().__init__()
        self.dice_weight = dice_weight
        self.bce_weight = bce_weight
        self.focal_weight = focal_weight
        self.dice = DiceLoss()
        self.focal = FocalLossWithLogits(gamma=focal_gamma, alpha=focal_alpha)
        self.register_buffer("positive_weight", torch.tensor([positive_weight], dtype=torch.float32))

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        bce = F.binary_cross_entropy_with_logits(
            logits,
            target,
            pos_weight=self.positive_weight.to(device=logits.device, dtype=logits.dtype),
        )
        dice = self.dice(logits, target)
        focal = self.focal(logits, target)
        return self.dice_weight * dice + self.bce_weight * bce + self.focal_weight * focal
