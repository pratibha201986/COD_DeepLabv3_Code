from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import torch


@dataclass
class MetricAccumulator:
    samples: int = 0
    dice_sum: float = 0.0
    iou_sum: float = 0.0
    mae_sum: float = 0.0
    pixel_correct: float = 0.0
    pixel_total: float = 0.0
    tp: float = 0.0
    tn: float = 0.0
    fp: float = 0.0
    fn: float = 0.0
    sm_sum: float = 0.0
    em_sum: float = 0.0
    fmax_sum: float = 0.0

    def update(self, prob: torch.Tensor, target: torch.Tensor, threshold: float = 0.35) -> None:
        prob = prob.detach().float().cpu()
        target = target.detach().float().cpu()
        pred = (prob > threshold).float()

        batch = prob.shape[0]
        self.samples += batch

        inter = (pred * target).sum(dim=(1, 2, 3))
        pred_sum = pred.sum(dim=(1, 2, 3))
        target_sum = target.sum(dim=(1, 2, 3))
        union = (pred + target).clamp(0, 1).sum(dim=(1, 2, 3))
        dice = (2.0 * inter + 1e-6) / (pred_sum + target_sum + 1e-6)
        iou = (inter + 1e-6) / (union + 1e-6)
        self.dice_sum += dice.sum().item()
        self.iou_sum += iou.sum().item()
        self.mae_sum += (prob - target).abs().flatten(start_dim=1).mean(dim=1).sum().item()

        self.tp += ((pred == 1) & (target == 1)).sum().item()
        self.tn += ((pred == 0) & (target == 0)).sum().item()
        self.fp += ((pred == 1) & (target == 0)).sum().item()
        self.fn += ((pred == 0) & (target == 1)).sum().item()
        self.pixel_correct += (pred == target).sum().item()
        self.pixel_total += target.numel()

        prob_np = prob.squeeze(1).numpy()
        target_np = target.squeeze(1).numpy()
        for p, g in zip(prob_np, target_np):
            g_bin = (g > 0.5).astype(np.float32)
            self.sm_sum += s_measure(p, g_bin)
            self.em_sum += enhanced_alignment_measure(p, g_bin)
            self.fmax_sum += max_f_beta(p, g_bin)

    def compute(self) -> dict[str, float]:
        precision = self.tp / (self.tp + self.fp + 1e-8)
        recall = self.tp / (self.tp + self.fn + 1e-8)
        specificity = self.tn / (self.tn + self.fp + 1e-8)
        f1 = 2.0 * precision * recall / (precision + recall + 1e-8)
        return {
            "mDice": self.dice_sum / max(self.samples, 1),
            "mIoU": self.iou_sum / max(self.samples, 1),
            "MAE": self.mae_sum / max(self.samples, 1),
            "Accuracy": self.pixel_correct / max(self.pixel_total, 1),
            "Precision": precision,
            "Recall": recall,
            "Specificity": specificity,
            "F1": f1,
            "Sm": self.sm_sum / max(self.samples, 1),
            "Em": self.em_sum / max(self.samples, 1),
            "Fmax": self.fmax_sum / max(self.samples, 1),
        }


def max_f_beta(prob: np.ndarray, gt: np.ndarray, beta2: float = 0.3) -> float:
    best = 0.0
    for threshold in np.linspace(0.0, 1.0, 256):
        pred = (prob >= threshold).astype(np.float32)
        tp = float((pred * gt).sum())
        precision = tp / (float(pred.sum()) + 1e-8)
        recall = tp / (float(gt.sum()) + 1e-8)
        score = (1.0 + beta2) * precision * recall / (beta2 * precision + recall + 1e-8)
        best = max(best, score)
    return float(best)


def enhanced_alignment_measure(prob: np.ndarray, gt: np.ndarray) -> float:
    if gt.max() == 0:
        return float((1.0 - prob).mean())
    if gt.min() == 1:
        return float(prob.mean())
    fm = prob - prob.mean()
    gm = gt - gt.mean()
    align = 2.0 * gm * fm / (gm * gm + fm * fm + 1e-8)
    enhanced = ((align + 1.0) ** 2) / 4.0
    return float(enhanced.mean())


def s_measure(prob: np.ndarray, gt: np.ndarray, alpha: float = 0.5) -> float:
    y = float(gt.mean())
    if y == 0.0:
        return float(1.0 - prob.mean())
    if y == 1.0:
        return float(prob.mean())
    return alpha * object_score(prob, gt) + (1.0 - alpha) * region_score(prob, gt)


def object_score(prob: np.ndarray, gt: np.ndarray) -> float:
    fg = prob[gt == 1]
    bg = 1.0 - prob[gt == 0]
    u = float(gt.mean())
    return u * object_subscore(fg) + (1.0 - u) * object_subscore(bg)


def object_subscore(values: np.ndarray) -> float:
    if values.size == 0:
        return 0.0
    mean = float(values.mean())
    std = float(values.std())
    return 2.0 * mean / (mean * mean + 1.0 + std + 1e-8)


def region_score(prob: np.ndarray, gt: np.ndarray) -> float:
    cy, cx = centroid(gt)
    h, w = gt.shape
    areas = [
        cx * cy,
        (w - cx) * cy,
        cx * (h - cy),
        (w - cx) * (h - cy),
    ]
    total = max(float(h * w), 1.0)
    weights = [area / total for area in areas]
    p_parts = [
        prob[:cy, :cx],
        prob[:cy, cx:],
        prob[cy:, :cx],
        prob[cy:, cx:],
    ]
    g_parts = [
        gt[:cy, :cx],
        gt[:cy, cx:],
        gt[cy:, :cx],
        gt[cy:, cx:],
    ]
    return float(sum(weight * ssim(p, g) for weight, p, g in zip(weights, p_parts, g_parts)))


def centroid(gt: np.ndarray) -> tuple[int, int]:
    ys, xs = np.where(gt == 1)
    h, w = gt.shape
    if len(xs) == 0:
        return h // 2, w // 2
    cx = int(round(float(xs.mean())))
    cy = int(round(float(ys.mean())))
    return max(1, min(cy, h - 1)), max(1, min(cx, w - 1))


def ssim(pred: np.ndarray, gt: np.ndarray) -> float:
    if pred.size == 0:
        return 0.0
    x = pred.astype(np.float64)
    y = gt.astype(np.float64)
    mean_x = x.mean()
    mean_y = y.mean()
    var_x = ((x - mean_x) ** 2).mean()
    var_y = ((y - mean_y) ** 2).mean()
    cov = ((x - mean_x) * (y - mean_y)).mean()
    numerator = 4.0 * mean_x * mean_y * cov
    denominator = (mean_x * mean_x + mean_y * mean_y) * (var_x + var_y) + 1e-8
    score = numerator / denominator if not math.isclose(denominator, 0.0) else 0.0
    return float(max(0.0, score))
