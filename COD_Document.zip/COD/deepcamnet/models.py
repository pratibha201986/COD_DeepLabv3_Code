from __future__ import annotations

import torch
from torch import nn
from torchvision import models
from torchvision.models.segmentation.deeplabv3 import DeepLabHead


def _load_resnet101(pretrained: bool) -> nn.Module:
    try:
        weights = models.segmentation.DeepLabV3_ResNet101_Weights.DEFAULT if pretrained else None
        model = models.segmentation.deeplabv3_resnet101(weights=weights)
    except AttributeError:
        model = models.segmentation.deeplabv3_resnet101(pretrained=pretrained)
    model.classifier = DeepLabHead(2048, 1)
    model.aux_classifier = None
    return model


def _load_mobilenet_v3(pretrained: bool) -> nn.Module:
    try:
        weights = models.segmentation.DeepLabV3_MobileNet_V3_Large_Weights.DEFAULT if pretrained else None
        model = models.segmentation.deeplabv3_mobilenet_v3_large(weights=weights)
    except AttributeError:
        model = models.segmentation.deeplabv3_mobilenet_v3_large(pretrained=pretrained)
    model.classifier = DeepLabHead(960, 1)
    model.aux_classifier = None
    return model


def build_deepcamnet(backbone: str, pretrained: bool = True) -> nn.Module:
    """Create one independently trained DeepCamNet configuration."""
    key = backbone.lower().replace("-", "").replace("_", "")
    if key in {"resnet101", "r101", "deeplabv3resnet101"}:
        return _load_resnet101(pretrained)
    if key in {"mobilenetv3", "mv3", "mobilenetv3large", "deeplabv3mobilenetv3"}:
        return _load_mobilenet_v3(pretrained)
    raise ValueError(f"Unsupported backbone: {backbone}")


def load_checkpoint(model: nn.Module, checkpoint_path: str, device: torch.device) -> dict:
    checkpoint = torch.load(checkpoint_path, map_location=device)
    state_dict = checkpoint.get("model", checkpoint)
    model.load_state_dict(state_dict, strict=True)
    return checkpoint
