from __future__ import annotations

import random
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from torchvision.transforms import functional as TF

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
MASK_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


@dataclass(frozen=True)
class ImageMaskPair:
    image: Path
    mask: Path


def find_image_mask_pairs(image_dir: str | Path, mask_dir: str | Path) -> list[ImageMaskPair]:
    """Match image and mask files by stem."""
    image_dir = Path(image_dir)
    mask_dir = Path(mask_dir)
    mask_by_stem = {
        path.stem: path
        for path in sorted(mask_dir.iterdir())
        if path.is_file() and path.suffix.lower() in MASK_EXTENSIONS
    }
    pairs: list[ImageMaskPair] = []
    for image_path in sorted(image_dir.iterdir()):
        if not image_path.is_file() or image_path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        mask_path = mask_by_stem.get(image_path.stem)
        if mask_path is not None:
            pairs.append(ImageMaskPair(image=image_path, mask=mask_path))
    return pairs


def read_split_file(split_file: str | Path, data_root: str | Path) -> list[ImageMaskPair]:
    """Read tab-separated image/mask relative paths from a split file."""
    split_file = Path(split_file)
    data_root = Path(data_root)
    pairs: list[ImageMaskPair] = []
    with split_file.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) != 2:
                raise ValueError(f"Invalid split line in {split_file}: {line}")
            pairs.append(ImageMaskPair(data_root / parts[0], data_root / parts[1]))
    return pairs


def write_split_file(split_file: str | Path, pairs: Iterable[ImageMaskPair], data_root: str | Path) -> None:
    """Write image/mask pairs as tab-separated paths relative to data_root."""
    split_file = Path(split_file)
    data_root = Path(data_root)
    split_file.parent.mkdir(parents=True, exist_ok=True)
    with split_file.open("w", encoding="utf-8", newline="\n") as handle:
        for pair in pairs:
            image_rel = pair.image.resolve().relative_to(data_root.resolve())
            mask_rel = pair.mask.resolve().relative_to(data_root.resolve())
            handle.write(f"{image_rel.as_posix()}\t{mask_rel.as_posix()}\n")


class PairedCODTransform:
    """Apply identical geometric transforms to image and mask."""

    def __init__(
        self,
        image_size: int = 256,
        train: bool = False,
        random_resized_crop: bool = False,
        crop_scale: tuple[float, float] = (0.8, 1.0),
        horizontal_flip_p: float = 0.5,
        rotation_degrees: float = 10.0,
        color_jitter: tuple[float, float, float, float] | None = None,
        normalize_mean: tuple[float, float, float] = (0.485, 0.456, 0.406),
        normalize_std: tuple[float, float, float] = (0.229, 0.224, 0.225),
    ) -> None:
        self.image_size = image_size
        self.train = train
        self.random_resized_crop = random_resized_crop
        self.crop_scale = crop_scale
        self.horizontal_flip_p = horizontal_flip_p
        self.rotation_degrees = rotation_degrees
        self.color_jitter = color_jitter
        self.normalize_mean = normalize_mean
        self.normalize_std = normalize_std

    def __call__(self, image: Image.Image, mask: Image.Image) -> tuple[torch.Tensor, torch.Tensor]:
        if self.train and self.random_resized_crop:
            i, j, h, w = transforms.RandomResizedCrop.get_params(
                image, scale=self.crop_scale, ratio=(1.0, 1.0)
            )
            image = TF.resized_crop(
                image, i, j, h, w, (self.image_size, self.image_size), InterpolationMode.BILINEAR
            )
            mask = TF.resized_crop(
                mask, i, j, h, w, (self.image_size, self.image_size), InterpolationMode.NEAREST
            )
        else:
            image = TF.resize(image, (self.image_size, self.image_size), InterpolationMode.BILINEAR)
            mask = TF.resize(mask, (self.image_size, self.image_size), InterpolationMode.NEAREST)

        if self.train and random.random() < self.horizontal_flip_p:
            image = TF.hflip(image)
            mask = TF.hflip(mask)

        if self.train and self.rotation_degrees > 0:
            angle = random.uniform(-self.rotation_degrees, self.rotation_degrees)
            image = TF.rotate(image, angle, interpolation=InterpolationMode.BILINEAR, fill=0)
            mask = TF.rotate(mask, angle, interpolation=InterpolationMode.NEAREST, fill=0)

        if self.train and self.color_jitter is not None:
            jitter = transforms.ColorJitter(*self.color_jitter)
            image = jitter(image)

        image_tensor = TF.to_tensor(image)
        image_tensor = TF.normalize(image_tensor, self.normalize_mean, self.normalize_std)
        mask_tensor = TF.to_tensor(mask)
        mask_tensor = (mask_tensor > 0.5).float()
        return image_tensor, mask_tensor


class CODSegmentationDataset(Dataset):
    """Camouflaged object segmentation dataset from image/mask pairs."""

    def __init__(
        self,
        pairs: list[ImageMaskPair],
        transform: PairedCODTransform,
        limit: int | None = None,
    ) -> None:
        self.pairs = pairs[:limit] if limit else pairs
        self.transform = transform

    def __len__(self) -> int:
        return len(self.pairs)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor, str]:
        pair = self.pairs[index]
        image = Image.open(pair.image).convert("RGB")
        mask = Image.open(pair.mask).convert("L")
        image_tensor, mask_tensor = self.transform(image, mask)
        return image_tensor, mask_tensor, pair.image.stem
